GFX-LAB automatic session diagnostics export v1
Device diagnostics, not authentic Raft Shader48 or PC pixel parity.
Session: 20261111-003111-483-82b5f0eb
Created UTC: 2026-11-11T00:31:40.6045770Z
Events and FULL Unity log stack traces: sessions/*/events.jsonl
Every saved test state and camera/device/GPU data: sessions/*/snapshots.jsonl
Per-session counts/errors: sessions/*/summary.json
Last model/channel report: latest/multi-report.json
Expected location: /storage/emulated/0/Download/Games/cl/test/g/
Captured log JSON is user-private; do not publish without reviewing it.
Original Shader48 restored: false
